#!/usr/local/bin/Rscript

################################################################################
### Simulation data generation script
##
## Created on: 2016-04-23
## Author: Kazuki Yoshida
################################################################################


###
### Capture data filename argument
################################################################################

## Specify the core count as the first argument
nCores <- as.numeric(commandArgs(trailingOnly = TRUE)[1])

## Execution not allowed without nCores
stopifnot(!is.na(nCores))


### Prepare environment
################################################################################

## sink() if being run non-interactively
if (sink.number() != 0) {sink()}
..scriptFileName.. <- gsub("^--file=", "", Filter(function(x) {grepl("^--file=", x)}, commandArgs()))
if (length(..scriptFileName..) == 1) {
    sink(file = paste0("./log/", basename(..scriptFileName..), ".txt"), split = TRUE)
}
options(width = 120)

## Record start time
start_time <- Sys.time()
cat("### Started ", as.character(start_time), "\n")

## Configure parallelization
## Parallel backend for foreach (also loads foreach and parallel; includes doMC)
library(doParallel)
## Reproducible parallelization
library(doRNG)
## Used by parallel::mclapply() as default
options(mc.cores = nCores)
## Used by doParallel as default
options(cores = nCores)
## Register doParallel as the parallel backend for foreach
## http://stackoverflow.com/questions/28989855/the-difference-between-domc-and-doparallel-in-r
doParallel::registerDoParallel(cores = nCores)
## Report multicore use
cat("### Using", foreach::getDoParWorkers(), "cores\n")
cat("### Using", foreach::getDoParName(), "as backend\n")

## Load packages
library(distributed)
library(tidyverse)


cat("
###
### Specify parameter sets
################################################################################\n")

## Create size set
lstNBase  <- list(10^5,2*10^4,2*10^4,5*10^3)
lstN4_20k <- list(2*10^4,2*10^4,2*10^4,2*10^4)
lstN8     <- list(10^5,2*10^4,2*10^4,5*10^3, 10^5,2*10^4,2*10^4,5*10^3)
lstN4_5k  <- list(5*10^3,5*10^3,5*10^3,5*10^3)

## Create treatment model coefficient sets
lstAlphasBaseNew <- list(c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)))
## Rare treatment approx 10%
lstAlphasRareTx <- list(c(alpha0 = -3.7, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                        c(alpha0 = -3.7, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                        c(alpha0 = -3.7, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)),
                        c(alpha0 = -3.7, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 7)))
## Varying number of confounders
lstAlphasVaryCon <- list(c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 5)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 10)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 20)),
                         c(alpha0 = -0.85, alphaX = 0.7 * seq(log(0.2), log(5), length.out = 40)))
## Null association
lstAlphasNull <- list(c(alpha0 = 0, alphaX = rep(0, 7)),
                      c(alpha0 = 0, alphaX = rep(0, 7)),
                      c(alpha0 = 0, alphaX = rep(0, 7)),
                      c(alpha0 = 0, alphaX = rep(0, 7)))


## Create outcome model coefficient sets
## Intercept, covariates, treatment, interaction
lstBetasBaseNew <- list(c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                          betaA = 0,
                          betaXA = rep(0,7)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                          betaA = 0,
                          betaXA = rep(0,7)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                          betaA = 0,
                          betaXA = rep(0,7)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                          betaA = 0,
                          betaXA = rep(0,7)))
## Rare disease around 1%
lstBetasRareDis1 <- list(c(beta0 = -5.5,
                           betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                           betaA = 0,
                           betaXA = rep(0,7)),
                         c(beta0 = -5.5,
                           betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                           betaA = 0,
                           betaXA = rep(0,7)),
                         c(beta0 = -5.5,
                           betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                           betaA = 0,
                           betaXA = rep(0,7)),
                         c(beta0 = -5.5,
                           betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                           betaA = 0,
                           betaXA = rep(0,7)))
## Rare disease around 0.1%
lstBetasRareDis.1 <- list(c(beta0 = -7.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = 0,
                            betaXA = rep(0,7)),
                          c(beta0 = -7.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = 0,
                            betaXA = rep(0,7)),
                          c(beta0 = -7.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = 0,
                            betaXA = rep(0,7)),
                          c(beta0 = -7.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = 0,
                            betaXA = rep(0,7)))
## Rare disease around 0.01%
lstBetasRareDis.01 <- list(c(beta0 = -10.0,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -10.0,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -10.0,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -10.0,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)))
## Vary disease incidence
lstBetasVaryDisInc <- list(c(beta0 = -3.5,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -5.5,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -7.5,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)),
                           c(beta0 = -10.0,
                             betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                             betaA = 0,
                             betaXA = rep(0,7)))
## Protective treatment
lstBetasProtectTx <- list(c(beta0 = -3.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = log(0.8),
                            betaXA = rep(0,7)),
                          c(beta0 = -3.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = log(0.8),
                            betaXA = rep(0,7)),
                          c(beta0 = -3.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = log(0.8),
                            betaXA = rep(0,7)),
                          c(beta0 = -3.5,
                            betaX = 0.5 * seq(log(0.2), log(5), length.out = 7),
                            betaA = log(0.8),
                            betaXA = rep(0,7)))
## Varying number of confounders
lstBetasVaryCon <- list(c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 5),
                          betaA = 0,
                          betaXA = rep(0,5)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 10),
                          betaA = 0,
                          betaXA = rep(0,10)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 20),
                          betaA = 0,
                          betaXA = rep(0,20)),
                        c(beta0 = -3.5,
                          betaX = 0.5 * seq(log(0.2), log(5), length.out = 40),
                          betaA = 0,
                          betaXA = rep(0,40)))
## Null covariates, protective treatment
lstBetasNull <- list(c(beta0 = -3.5,
                       betaX = rep(0, 7),
                       betaA = log(0.8),
                       betaXA = rep(0, 7)),
                     c(beta0 = -3.5,
                       betaX = rep(0, 7),
                       betaA = log(0.8),
                       betaXA = rep(0, 7)),
                     c(beta0 = -3.5,
                       betaX = rep(0, 7),
                       betaA = log(0.8),
                       betaXA = rep(0, 7)),
                     c(beta0 = -3.5,
                       betaX = rep(0, 7),
                       betaA = log(0.8),
                       betaXA = rep(0, 7)))

## Create survival outcome model parameter sets
##
lstSurvParamsBaseNew <- list(c(-log(0.97), -log(0.9), 1),
                             c(-log(0.97), -log(0.9), 1),
                             c(-log(0.97), -log(0.9), 1),
                             c(-log(0.97), -log(0.9), 1))
##
lstSurvParamsRareDis1 <- list(c(-log(0.995), -log(0.9), 1),
                              c(-log(0.995), -log(0.9), 1),
                              c(-log(0.995), -log(0.9), 1),
                              c(-log(0.995), -log(0.9), 1))
##
lstSurvParamsRareDis.1 <- list(c(-log(0.9995), -log(0.9), 1),
                               c(-log(0.9995), -log(0.9), 1),
                               c(-log(0.9995), -log(0.9), 1),
                               c(-log(0.9995), -log(0.9), 1))
##
lstSurvParamsRareDis.01 <- list(c(-log(0.99995), -log(0.9), 1),
                                c(-log(0.99995), -log(0.9), 1),
                                c(-log(0.99995), -log(0.9), 1),
                                c(-log(0.99995), -log(0.9), 1))
##
lstSurvParamsVaryDisInc <- list(c(-log(0.97), -log(0.9), 1),
                                c(-log(0.995), -log(0.9), 1),
                                c(-log(0.9995), -log(0.9), 1),
                                c(-log(0.99995), -log(0.9), 1))

cat("
###
### Create scenarios
################################################################################\n")

## Actually generate scenarios
Scenarios <- GenerateScenarios(lstLstN          = list("01" = lstNBase,
                                                       "02" = lstNBase,
                                                       "03" = lstNBase,
                                                       "04" = lstNBase,
                                                       "05" = lstNBase,
                                                       "06" = lstN4_20k,
                                                       "07" = lstNBase,
                                                       "08" = c(lstNBase,lstNBase),
                                                       "09" = lstN4_20k,
                                                       "10" = lstN4_5k,
                                                       "11" = lstNBase,
                                                       "12" = lstNBase),
                               lstLstAlphas     = list("01" = lstAlphasBaseNew,
                                                       "02" = lstAlphasRareTx,
                                                       "03" = lstAlphasBaseNew,
                                                       "04" = lstAlphasBaseNew,
                                                       "05" = lstAlphasBaseNew,
                                                       "06" = lstAlphasBaseNew,
                                                       "07" = lstAlphasBaseNew,
                                                       "08" = c(lstAlphasBaseNew,lstAlphasBaseNew),
                                                       "09" = lstAlphasVaryCon,
                                                       "10" = lstAlphasBaseNew,
                                                       "11" = lstAlphasNull,
                                                       "12" = lstAlphasNull),
                               lstLstBetas      = list("01" = lstBetasBaseNew,
                                                       "02" = lstBetasBaseNew,
                                                       "03" = lstBetasRareDis1,
                                                       "04" = lstBetasRareDis.1,
                                                       "05" = lstBetasRareDis.01,
                                                       "06" = lstBetasVaryDisInc,
                                                       "07" = lstBetasProtectTx,
                                                       "08" = c(lstBetasBaseNew,lstBetasBaseNew),
                                                       "09" = lstBetasVaryCon,
                                                       "10" = lstBetasRareDis1,
                                                       "11" = lstBetasNull,
                                                       "12" = lstBetasProtectTx),
                               lstLstSurvParams = list("01" = lstSurvParamsBaseNew,
                                                       "02" = lstSurvParamsBaseNew,
                                                       "03" = lstSurvParamsRareDis1,
                                                       "04" = lstSurvParamsRareDis.1,
                                                       "05" = lstSurvParamsRareDis.01,
                                                       "06" = lstSurvParamsVaryDisInc,
                                                       "07" = lstSurvParamsBaseNew,
                                                       "08" = c(lstSurvParamsBaseNew,lstSurvParamsBaseNew),
                                                       "09" = lstSurvParamsBaseNew,
                                                       "10" = lstSurvParamsRareDis1,
                                                       "11" = lstSurvParamsBaseNew,
                                                       "12" = lstSurvParamsBaseNew),
                               mix = FALSE)
names(Scenarios) <- c("new base",
                      "rare (10%) treatment",
                      "rare (1%) disease",
                      "rare (0.1%) disease",
                      "rare (0.01%) disease",
                      "varying disease prevalence (5,1,0.1,0.01)",
                      "protective treatment",
                      "8 sites",
                      "varying confounder counts",
                      "all small sites with 1% disease",
                      ## The following are experimental to assess simulation.
                      "null covariates, protective treatment log(0.8)",
                      "predictors, protective treatment log(0.8)")
print(Scenarios)


cat("
###
### Generate datasets
################################################################################\n")

set.seed(201605130)
parts <- 10
R <- 50

## Check for the data subfolder if not available
if (!("data" %in% dir())) {
    stop("data subfolder is not available. Create one.")
}
## Move to the data subfolder
setwd("./data")

## Parallelization at the scenario level.
## If there are fewer scenarios than cores requested, CPU time is wasted.
GenerateDataForAllScenarios(Scenarios = Scenarios,
                            parts = parts,
                            R = R)


################################################################################
cat("\n### Record package versions\n")
print(sessionInfo())
## Record execution time
end_time <- Sys.time()
cat("### Started ", as.character(start_time), "\n")
cat("### Finished ", as.character(end_time), "\n")
print(end_time - start_time)
## Stop sinking to a file if active
if (sink.number() != 0) {sink()}
