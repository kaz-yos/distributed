#!/usr/local/bin/Rscript

################################################################################
### Assess result files (simplified for December 2016 reporting)
##
## Created on: 2016-12-07
## Author: Kazuki Yoshida
################################################################################


###
### Prepare environment
################################################################################

## sink() if being run non-interactively
if (sink.number() != 0) {sink()}
..scriptFileName.. <- gsub("^--file=", "", Filter(function(x) {grepl("^--file=", x)}, commandArgs()))
if (length(..scriptFileName..) == 1) {
    sink(file = paste0("./log/", basename(..scriptFileName..), ".txt"), split = TRUE)
    options(width = 100)
}

## Record start time
start_time <- Sys.time()
cat("### Started ", as.character(start_time), "\n")

## Configure parallelization
## Parallel backend for foreach (also loads foreach and parallel; includes doMC)
library(doParallel)
## Reproducible parallelization
library(doRNG)
## Detect core count
nCores <- min(parallel::detectCores(), 8)
## Used by parallel::mclapply() as default
options(mc.cores = nCores)
## Used by doParallel as default
options(cores = nCores)
## Register doParallel as the parallel backend for foreach
## http://stackoverflow.com/questions/28989855/the-difference-between-domc-and-doparallel-in-r
doParallel::registerDoParallel(cores = nCores)
## Report multicore use
cat("### Using", foreach::getDoParWorkers(), "cores\n")
cat("### Using", foreach::getDoParName(), "as backend\n")

## Load packages
library(tidyverse)
library(distributed)
library(openxlsx)


cat("
###
### Load data
################################################################################\n")

dirName <- "./data/"
analysisFileNames <- paste0(dirName,
                            Filter(f = function(elt) {
                                grepl(".*ScenarioAnalyzed.*", elt)
                            }, x = dir(dirName)))


### Loop over all analysis result files and load them into a list
lstAnalysis <- lapply(analysisFileNames, function(file) {

    ## Load file corresponding to a part within a scenario
    load(file)

    ## Binary indicator for valid iterations
    logi_valid_iter <- !sapply(lstIterAnalyzed, (distributed:::is.error))
    ## Valid iteration numbers
    valid_iter <- seq_along(lstIterAnalyzed)[logi_valid_iter]

    ## report results
    cat("## Working on", file, "\n")
    cat("##  Valid iterations:", sum(logi_valid_iter), "out of", length(logi_valid_iter), "\n")
    if (any(!logi_valid_iter)) {
        cat("##  Failed iterations are\n")
        print(which(!logi_valid_iter))
        cat("##  Failure reasons are\n")
        print(unique(lstIterAnalyzed[sapply(lstIterAnalyzed, (distributed:::is.error))]))
    }

    ## Loop over iterations within a part
    lst <- lapply(valid_iter, function(i) {

        cbind(scenario = scenarioCount,
              part = partCount,
              iter = i,
              ## Iteration-level df
              lstIterAnalyzed[[i]],
              stringsAsFactors = FALSE)
    })

    ## Combine as df at part level
    df <- dplyr::bind_rows(lst)

    ## Add scenario as an attribute
    attr(df, "ScenarioDistResNet") <- ScenarioDistResNet

    df
})

cat("
###  Show first file, first part data\n")
head(head(lstAnalysis, 1)[[1]])
cat("
###  Show last file, last part data\n")
tail(tail(lstAnalysis, 1)[[1]])


### Create a data frame of all analysis results
dfAnalysis <- dplyr::bind_rows(lstAnalysis)


cat("###  Check scenario 9 stratified analysis with riskset \n")
dfAnalysis[dfAnalysis$data == "risksets" &
           dfAnalysis$scenario == 9 &
           dfAnalysis$outcome == "survival" &
           dfAnalysis$method %in% c("eDrsSStrata","ePsStrata"),
           c("scenario", "part", "iter", "outcome", "method", "data", "coef", "var")] %>% head(n = 20)


###  Split "method" variable into several metrics

dfAnalysis$method <- as.character(dfAnalysis$method)
## Summary score
dfAnalysis$score <- SeqGsub(dfAnalysis$method,
                            c(".*ePs.*", "PS",
                              ".*eDrs.*", "DRS",
                              ## Truth
                              "^t.*", "None",
                              ## Unadjusted
                              "^unadj.*", "None"))
dfAnalysis$score <- factor(dfAnalysis$score,
                           levels = c("PS","DRS","None"))
## Adjustment method
dfAnalysis$adjust <- SeqGsub(dfAnalysis$method,
                             c(".*Match.*", "Match.",
                               ".*Strata.*", "Strat.",
                               ".*SIptw.*", "IPTW",
                               ".*Mw.*", "MW",
                               ## Truth
                               "^t.*", "Truth",
                               ## Unadjusted
                               "^unadj.*", "Unadj."))
dfAnalysis$adjust <- factor(dfAnalysis$adjust,
                            levels = c("Match.","Strat.","IPTW","MW",
                                       "Truth","Unadj."))
## Note estimands
dfAnalysis$data <- as.character(dfAnalysis$data)
dfAnalysis$data[grepl("tAll.*", dfAnalysis$method)]       <- "truth (ATE)"
dfAnalysis$data[grepl("tTreated.*", dfAnalysis$method)]   <- "truth (ATT)"
dfAnalysis$data[grepl("tUntreated.*", dfAnalysis$method)] <- "truth (ATU)"
dfAnalysis$data <- factor(dfAnalysis$data,
                          levels = c("meta", "summary", "risksets", "dataset",
                                     "truth (ATE)", "truth (ATT)",  "truth (ATU)"))

## Approximation method
dfAnalysis$approx <- SeqGsub(dfAnalysis$method,
                             c(".*E$", "Efron",
                               ".*B$", "Breslow"))
dfAnalysis$approx[!dfAnalysis$approx %in% c("Efron","Breslow")] <- ""


cat("
###  Show first part of combined data frame\n")
head(dfAnalysis)
cat("
###  Show last part of combined data frame\n")
tail(dfAnalysis)


###
### Invalid data handling
cat("
###  Check scenario 9 stratified/riskset failure\n")

dfAnalysis[with(dfAnalysis, scenario == 9 & method == "ePsStrataB" & data == "risksets"),]

cat("
###  Show extreme coefficients (coef > 5; will be dropped)\n")
dfAnalysis[!is.na(dfAnalysis$coef) & abs(dfAnalysis$coef) > 5,
           c("scenario", "part", "iter", "outcome", "method", "data", "coef", "var")] %>% as.data.frame
## Drop coef and var for these
dfAnalysis[!is.na(dfAnalysis$coef) & abs(dfAnalysis$coef) > 5,
           c("coef", "var")] <- NA

cat("
###  Show extreme variance (var > 5; will be dropped)\n")
dfAnalysis[!is.na(dfAnalysis$var) & abs(dfAnalysis$var) > 5,
           c("scenario", "part", "iter", "outcome", "method", "data", "coef", "var")] %>% as.data.frame
## Drop coef and var for these
dfAnalysis[!is.na(dfAnalysis$var) & abs(dfAnalysis$var) > 5,
           c("coef", "var")] <- NA

cat("
###  Drop coef-only or var-only observations these are broken\n")
dfAnalysis[is.na(dfAnalysis$coef) & !is.na(dfAnalysis$var), "var"] <- NA
dfAnalysis[!is.na(dfAnalysis$coef) & is.na(dfAnalysis$var), "coef"] <- NA


cat("
###
### Assess data
################################################################################\n")

###  Construct operational characteristics
dfSummary <- dfAnalysis %>%
    ## Collapsing over part & iter (all interations)
    group_by(scenario, data, outcome, score, adjust, approx, method) %>%
    summarize(mean_coef = mean(coef, na.rm = TRUE),
              mean_var  = mean(var, na.rm = TRUE),
              true_var  = var(coef, na.rm = TRUE),
              ratio_var = mean_var / true_var,
              ratio_se  = sqrt(mean_var) / sqrt(true_var),
              ## MSE assuming true effect of 0
              mse_true0 = true_var + mean_coef^2)

## Add true_var to iteration level dataset
dfAnalysis <- left_join(x = dfAnalysis,
          y = select(dfSummary, scenario, data, outcome, score, adjust, approx, method, true_var))

## SE_hat / SE ratio for each iteration
dfAnalysis <- dfAnalysis %>%
    group_by(scenario, data, outcome, score, adjust, approx, method) %>%
    mutate(ratio_var = var / true_var,
           ratio_se = sqrt(var) / sqrt(true_var))


cat("
###  Assess weighting methods\n")
## Check if meta-analysis IPTW are bad
subset(dfSummary, adjust %in% c("IPTW","MW") & data == "meta")[,c("scenario","outcome","method","mean_coef","mean_var","true_var")] %>% as.data.frame

subset(dfAnalysis, adjust %in% c("IPTW","MW") & iter %in% c(1,5) & outcome == "survival" & data == "meta" & scenario == 5)[,c("scenario","iter","outcome","method","coef","var","coef_site1", "coef_site2", "coef_site3", "coef_site4",
"var_site1", "var_site2", "var_site3", "var_site4")] %>% as.data.frame


cat("
###  Summaries\n")

dfSummary[dfSummary$scenario == 1,] %>%
    arrange(outcome, score, adjust, data) %>%
    as.data.frame %>%
    print(digits = 3)

## Write out full summary
openxlsx::write.xlsx(as.data.frame(dfSummary[dfSummary$scenario == 1,]),
                     file = "./summary/summary.xlsx")

cat("
###  Least biased methods\n")
subset(dfSummary, outcome == "binary") %>%
    arrange(scenario, abs(mean_coef))
subset(dfSummary, outcome == "survival") %>%
    arrange(scenario, abs(mean_coef))


cat("
###  Smallest variance methods\n")
subset(dfSummary, outcome == "binary") %>%
    arrange(scenario, abs(true_var))
subset(dfSummary, outcome == "survival") %>%
    arrange(scenario, abs(true_var))


cat("
###  Smallest MSE methods\n")
subset(dfSummary, outcome == "binary") %>%
    arrange(scenario, abs(mse_true0))
subset(dfSummary, outcome == "survival") %>%
    arrange(scenario, abs(mse_true0))

cat("
###  Equivalent methods (up to 7 decimals)\n")

## Sort
dfSummary2 <- dfSummary[,c("mean_coef","mean_var","data","outcome","score","adjust","approx")] %>%
    arrange(outcome, mean_coef, mean_var)

## Only duplicated rows are wanted
dupFromAbove <- duplicated(round(dfSummary2[c("mean_coef","mean_var")], 7))
dupFromBelow <- duplicated(round(dfSummary2[c("mean_coef","mean_var")], 7), fromLast = TRUE)
dfSummary2[(dupFromAbove + dupFromBelow) > 0,] %>%
    as.data.frame


cat("
###
### Graphing
################################################################################\n")

## Color configuration
## http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/#a-colorblind-friendly-palette
cbPalette <- c("#E69F00", "#56B4E9", "#009E73", "#CC79A7", "#F0E442", "#0072B2", "#D55E00", "#999999")

cat("
###  Drop unadjusted and truth\n")
dfAnalysis <- subset(dfAnalysis, !(adjust %in% c("Truth","Unadj.")))

theme_clean <- theme_bw() + theme(legend.key = element_blank(),
                                  axis.text.x = element_text(angle = 90, hjust = 1),
                                  strip.background = element_blank(),
                                  plot.title = element_text(hjust = 0.5))

cat("
###  All methods by non-NA estimates (binary)\n")
pdf(file = "./summary/summary_nonNA_binary.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {
        df <- df %>%
            filter(approx != "Efron",
                   outcome == "binary") %>%
            group_by(score, adjust, data, scenario) %>%
            summarize(perc_failure = sum(!is.na(coef)) / length(coef) * 100)
        gg <- ggplot(data = df,
                     mapping = aes(x    = data,
                                   y    = perc_failure,
                                   fill = data)) +
            geom_bar(stat = "identity") +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_y_continuous(limit = c(0,100)) +
            scale_fill_manual(values = cbPalette) +
            labs(title = paste0("Binary analysis successful iterations (%). Scenario ",
                                unique(df$scenario)),
                 y = "% successful iterations") +
            guides(fill = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  All methods by non-NA estimates (survival)\n")
pdf(file = "./summary/summary_nonNA_survival.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {
        df <- df %>%
            filter(approx != "Efron",
                   outcome == "survival") %>%
            group_by(score, adjust, data, scenario) %>%
            summarize(perc_failure = sum(!is.na(coef)) / length(coef) * 100)
        gg <- ggplot(data = df,
                     mapping = aes(x    = data,
                                   y    = perc_failure,
                                   fill = data)) +
            geom_bar(stat = "identity") +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_y_continuous(limit = c(0,100)) +
            scale_fill_manual(values = cbPalette) +
            labs(title = paste0("Survival analysis successful iterations (%). Scenario ",
                                unique(df$scenario)),
                 y = "% successful iterations") +
            guides(fill = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  All methods by coefficient points (binary)\n")
pdf(file = "./summary/summary_coefs_binary.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {

        gg <- ggplot(data = subset(df, approx != "Efron" &
                                       outcome == "binary"),
               mapping = aes(x     = data,
                             y     = coef,
                             color = data)) +
            geom_boxplot() +
            stat_summary(fun.y = mean, colour = "darkred", geom = "point",
                         shape = 4, size = 1, show.legend = FALSE) +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_color_manual(values = cbPalette) +
            labs(title = paste0("Binary analysis log OR. Scenario ",
                                unique(df$scenario)),
                 x = NULL, y = "log OR") +
            guides(color = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  All methods by coefficient points (survival)\n")
pdf(file = "./summary/summary_coefs_survival.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {

        gg <- ggplot(data = subset(df, approx != "Efron" &
                                       outcome == "survival"),
                     mapping = aes(x     = data,
                                   y     = coef,
                                   color = data)) +
            geom_boxplot() +
            stat_summary(fun.y = mean, colour = "darkred", geom = "point",
                         shape = 4, size = 1, show.legend = FALSE) +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_color_manual(values = cbPalette) +
            labs(title = paste0("Survival analysis log HR. Scenario ",
                                unique(df$scenario)),
                 x = NULL, y = "log HR") +
            guides(color = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  All methods by SE/true SE ratio points (binary)\n")
pdf(file = "./summary/summary_se_binary.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {
        gg <- ggplot(data = subset(df, approx != "Efron" &
                                       !grepl("truth", as.character(data)) &
                                       outcome == "binary"),
                     mapping = aes(x     = data,
                                   y     = ratio_se,
                                   color = data)) +
            geom_boxplot() +
            stat_summary(fun.y = mean, colour = "darkred", geom = "point",
                         shape = 4, size = 1, show.legend = FALSE) +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_color_manual(values = cbPalette) +
            labs(title = paste0("Binary analysis estimated SE / true SE ratio distribution. Scenario ",
                                unique(df$scenario)),
                 x = NULL, y = "Estimated SE(log OR) / true SE(log OR)") +
            guides(color = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  All methods by SE/true SE ratio points (survival)\n")
pdf(file = "./summary/summary_se_survival.pdf", width = 7.5, height = 6, family = "sans")

## Use Breslow or non-approximation only
split(dfAnalysis, dfAnalysis$scenario) %>%
    ## Loop over scenarios
    sapply(., function(df) {
        gg <- ggplot(data = subset(df, approx != "Efron" &
                                       !grepl("truth", as.character(data)) &
                                       outcome == "survival"),
                     mapping = aes(x     = data,
                                   y     = ratio_se,
                                   color = data)) +
            geom_boxplot() +
            stat_summary(fun.y = mean, colour = "darkred", geom = "point",
                         shape = 4, size = 1, show.legend = FALSE) +
            facet_wrap(~ score + adjust, scale = "free_x", nrow = 2) +
            scale_color_manual(values = cbPalette) +
            labs(title = paste0("Survival analysis estimated SE / true SE ratio distribution. Scenario ",
                                unique(df$scenario)),
                 x = NULL, y = "Estimated SE(log HR) / true SE(log HR)") +
            guides(color = FALSE) +
            theme_clean
        out <- try(print(gg))
        ifelse(is.error(out), out, "success")
    })

dev.off()


cat("
###  Bias-variance plot\n")
pdf(file = "./summary/summary_plots2.pdf", width = 10, height = 7, family = "sans")

bv_plot_b <-
    ggplot(data = subset(dfSummary, outcome == "binary"),
           mapping = aes(x = mean_coef, y = sqrt(true_var),
                         color = data, shape = approx)) +
    geom_point(size = 5, alpha = 0.5) +
    facet_wrap(~ score + adjust) +
            scale_color_manual(values = cbPalette) +
    scale_y_continuous(limit = c(0, NA)) +
    theme_bw() + theme(legend.key = element_blank()) +
    labs(x = "Bias", y = "True standard error")
bv_plot_b + labs(title = "Bias-se plot: binary outcome")
bv_plot_b %+%
    subset(dfSummary, outcome == "survival") +
    labs(title = "Bias-se plot: survival outcome")

dev.off()


cat("
###  Individual site analysis (binary)\n")

pdf(file = "./summary/summary_individual_sites_binary.pdf", width = 10, height = 7, family = "sans")

## Site-specific estimated coefficients (variability is true)
dfSites <- gather(data = subset(dfAnalysis, outcome == "binary" & data == "meta"),
       key = site, value = coef_site,
       coef_site1, coef_site2, coef_site3, coef_site4)
dfSites$site <- gsub("coef_site", "", dfSites$site)

ggplot(data = dfSites, mapping = aes(x     = site,
                                     y     = coef_site,
                                     color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
            scale_color_manual(values = cbPalette) +
    labs("Site-Specific Coefficients") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific true variance
dfSites %>%
    group_by(site, score, adjust, approx) %>%
    summarize(var_site = var(coef_site, na.rm = TRUE)) %>%
    ggplot(data = ., mapping = aes(x     = site,
                                   y     = var_site,
                                   color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific True Variance") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific estimated variance (variability is true)
dfSites2 <- gather(data = subset(dfAnalysis, outcome == "binary" & data == "meta"),
       key = site, value = var_site,
       var_site1, var_site2, var_site3, var_site4)
dfSites2$site <- gsub("var_site", "", dfSites2$site)

ggplot(data = dfSites2, mapping = aes(x     = site,
                                      y     = var_site,
                                      color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific Variances") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific estimated inverse variance
ggplot(data = dfSites2, mapping = aes(x     = site,
                                      y     = 1/var_site,
                                      color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific Inverse Variances") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

dev.off()


cat("
###  Individual site analysis (survival)\n")

pdf(file = "./summary/summary_individual_sites_survival.pdf", width = 10, height = 7, family = "sans")

## Site-specific estimated coefficients
dfSites <- gather(data = subset(dfAnalysis, outcome == "survival" & data == "meta"),
       key = site, value = coef_site,
       coef_site1, coef_site2, coef_site3, coef_site4)
dfSites$site <- gsub("coef_site", "", dfSites$site)

ggplot(data = dfSites, mapping = aes(x     = site,
                                     y     = coef_site,
                                     color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific Coefficients") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific true variance
dfSites %>%
    group_by(site, score, adjust, approx) %>%
    summarize(var_site = var(coef_site, na.rm = TRUE)) %>%
    ggplot(data = ., mapping = aes(x     = site,
                                   y     = var_site,
                                   color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific True Variance") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific estimated variance
dfSites2 <- gather(data = subset(dfAnalysis, outcome == "survival" & data == "meta"),
       key = site, value = var_site,
       var_site1, var_site2, var_site3, var_site4)

dfSites2$site <- gsub("coef_site", "", dfSites2$site)

ggplot(data = dfSites2, mapping = aes(x     = site,
                                      y     = var_site,
                                      color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific Variances") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

## Site-specific estimated inverse variance
ggplot(data = dfSites2, mapping = aes(x     = site,
                                      y     = 1/var_site,
                                      color = site)) +
    geom_boxplot() +
    geom_point(mapping = aes(shape = approx)) +
    facet_wrap(~ score + adjust) +
    labs("Site-Specific Inverse Variances") +
    theme_bw() + theme(legend.key = element_blank(),
                       axis.text.x = element_text(angle = 90, hjust = 1))

dev.off()


################################################################################
cat("
###
### Record package versions etc
################################################################################\n")
print(sessionInfo())
## Record execution time
end_time <- Sys.time()
cat("### Started  ", as.character(start_time), "\n")
cat("### Finished ", as.character(end_time), "\n")
print(end_time - start_time)
## Stop sinking to a file if active
if (sink.number() != 0) {sink()}
